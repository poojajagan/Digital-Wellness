###### Class kotlin.UByte (kotlin.UByte)
.class public final Lkotlin/UByte;
.super Ljava/lang/Object;
.source "UByte.kt"

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lkotlin/UByte$Companion;
    }
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lkotlin/UByte;",
        ">;"
    }
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000n\n\u0002\u0018\u0002\n\u0002\u0010\u000f\n\u0000\n\u0002\u0010\u0005\n\u0002\u0008\t\n\u0002\u0010\u0008\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u000b\n\u0002\u0010\u000b\n\u0002\u0010\u0000\n\u0002\u0008!\n\u0002\u0018\u0002\n\u0002\u0008\u0011\n\u0002\u0010\u0006\n\u0002\u0008\u0003\n\u0002\u0010\u0007\n\u0002\u0008\u0005\n\u0002\u0010\t\n\u0002\u0008\u0003\n\u0002\u0010\n\n\u0002\u0008\u0003\n\u0002\u0010\u000e\n\u0002\u0008\u000e\u0008\u0087@\u0018\u0000 v2\u0008\u0012\u0004\u0012\u00020\u00000\u0001:\u0001vB\u0014\u0008\u0001\u0012\u0006\u0010\u0002\u001a\u00020\u0003\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u0004\u0010\u0005J\u001b\u0010\u0008\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\n\u0010\u000bJ\u001b\u0010\u000c\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0000H\u0097\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u000e\u0010\u000fJ\u001b\u0010\u000c\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u0011\u0010\u0012J\u001b\u0010\u000c\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u0014\u0010\u0015J\u001b\u0010\u000c\u001a\u00020\r2\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u0017\u0010\u0018J\u0016\u0010\u0019\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u001a\u0010\u0005J\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u001c\u0010\u000fJ\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u001d\u0010\u0012J\u001b\u0010\u001b\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\u001e\u0010\u001fJ\u001b\u0010\u001b\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008 \u0010\u0018J\u001a\u0010!\u001a\u00020\"2\u0008\u0010\t\u001a\u0004\u0018\u00010#H\u00d6\u0003\u00a2\u0006\u0004\u0008$\u0010%J\u001b\u0010&\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008\'\u0010\u000fJ\u001b\u0010&\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008(\u0010\u0012J\u001b\u0010&\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008)\u0010\u001fJ\u001b\u0010&\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008*\u0010\u0018J\u0010\u0010+\u001a\u00020\rH\u00d6\u0001\u00a2\u0006\u0004\u0008,\u0010-J\u0016\u0010.\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008/\u0010\u0005J\u0016\u00100\u001a\u00020\u0000H\u0087\u0008\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u00081\u0010\u0005J\u001b\u00102\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u00083\u0010\u000fJ\u001b\u00102\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u00084\u0010\u0012J\u001b\u00102\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u00085\u0010\u001fJ\u001b\u00102\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u00086\u0010\u0018J\u001b\u00107\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u00088\u0010\u000bJ\u001b\u00107\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u00089\u0010\u0012J\u001b\u00107\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008:\u0010\u001fJ\u001b\u00107\u001a\u00020\u00162\u0006\u0010\t\u001a\u00020\u0016H\u0087\u0008\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008;\u0010<J\u001b\u0010=\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008>\u0010\u000bJ\u001b\u0010?\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008@\u0010\u000fJ\u001b\u0010?\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008A\u0010\u0012J\u001b\u0010?\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008B\u0010\u001fJ\u001b\u0010?\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008C\u0010\u0018J\u001b\u0010D\u001a\u00020E2\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008F\u0010GJ\u001b\u0010H\u001a\u00020E2\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008I\u0010GJ\u001b\u0010J\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008K\u0010\u000fJ\u001b\u0010J\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008L\u0010\u0012J\u001b\u0010J\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008M\u0010\u001fJ\u001b\u0010J\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008N\u0010\u0018J\u001b\u0010O\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0000H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008P\u0010\u000fJ\u001b\u0010O\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0010H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008Q\u0010\u0012J\u001b\u0010O\u001a\u00020\u00132\u0006\u0010\t\u001a\u00020\u0013H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008R\u0010\u001fJ\u001b\u0010O\u001a\u00020\u00102\u0006\u0010\t\u001a\u00020\u0016H\u0087\n\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008S\u0010\u0018J\u0010\u0010T\u001a\u00020\u0003H\u0087\u0008\u00a2\u0006\u0004\u0008U\u0010\u0005J\u0010\u0010V\u001a\u00020WH\u0087\u0008\u00a2\u0006\u0004\u0008X\u0010YJ\u0010\u0010Z\u001a\u00020[H\u0087\u0008\u00a2\u0006\u0004\u0008\\\u0010]J\u0010\u0010^\u001a\u00020\rH\u0087\u0008\u00a2\u0006\u0004\u0008_\u0010-J\u0010\u0010`\u001a\u00020aH\u0087\u0008\u00a2\u0006\u0004\u0008b\u0010cJ\u0010\u0010d\u001a\u00020eH\u0087\u0008\u00a2\u0006\u0004\u0008f\u0010gJ\u000f\u0010h\u001a\u00020iH\u0016\u00a2\u0006\u0004\u0008j\u0010kJ\u0016\u0010l\u001a\u00020\u0000H\u0087\u0008\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008m\u0010\u0005J\u0016\u0010n\u001a\u00020\u0010H\u0087\u0008\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008o\u0010-J\u0016\u0010p\u001a\u00020\u0013H\u0087\u0008\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008q\u0010cJ\u0016\u0010r\u001a\u00020\u0016H\u0087\u0008\u00f8\u0001\u0001\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008s\u0010gJ\u001b\u0010t\u001a\u00020\u00002\u0006\u0010\t\u001a\u00020\u0000H\u0087\u000c\u00f8\u0001\u0000\u00a2\u0006\u0004\u0008u\u0010\u000bR\u0016\u0010\u0002\u001a\u00020\u00038\u0000X\u0081\u0004\u00a2\u0006\u0008\n\u0000\u0012\u0004\u0008\u0006\u0010\u0007\u0088\u0001\u0002\u0092\u0001\u00020\u0003\u00f8\u0001\u0000\u0082\u0002\u0008\n\u0002\u0008\u0019\n\u0002\u0008!\u00a8\u0006w"
    }
    d2 = {
        "Lkotlin/UByte;",
        "",
        "data",
        "",
        "constructor-impl",
        "(B)B",
        "getData$annotations",
        "()V",
        "and",
        "other",
        "and-7apg3OU",
        "(BB)B",
        "compareTo",
        "",
        "compareTo-7apg3OU",
        "(BB)I",
        "Lkotlin/UInt;",
        "compareTo-WZ4Q5Ns",
        "(BI)I",
        "Lkotlin/ULong;",
        "compareTo-VKZWuLQ",
        "(BJ)I",
        "Lkotlin/UShort;",
        "compareTo-xj2QHRw",
        "(BS)I",
        "dec",
        "dec-w2LRezQ",
        "div",
        "div-7apg3OU",
        "div-WZ4Q5Ns",
        "div-VKZWuLQ",
        "(BJ)J",
        "div-xj2QHRw",
        "equals",
        "",
        "",
        "equals-impl",
        "(BLjava/lang/Object;)Z",
        "floorDiv",
        "floorDiv-7apg3OU",
        "floorDiv-WZ4Q5Ns",
        "floorDiv-VKZWuLQ",
        "floorDiv-xj2QHRw",
        "hashCode",
        "hashCode-impl",
        "(B)I",
        "inc",
        "inc-w2LRezQ",
        "inv",
        "inv-w2LRezQ",
        "minus",
        "minus-7apg3OU",
        "minus-WZ4Q5Ns",
        "minus-VKZWuLQ",
        "minus-xj2QHRw",
        "mod",
        "mod-7apg3OU",
        "mod-WZ4Q5Ns",
        "mod-VKZWuLQ",
        "mod-xj2QHRw",
        "(BS)S",
        "or",
        "or-7apg3OU",
        "plus",
        "plus-7apg3OU",
        "plus-WZ4Q5Ns",
        "plus-VKZWuLQ",
        "plus-xj2QHRw",
        "rangeTo",
        "Lkotlin/ranges/UIntRange;",
        "rangeTo-7apg3OU",
        "(BB)Lkotlin/ranges/UIntRange;",
        "rangeUntil",
        "rangeUntil-7apg3OU",
        "rem",
        "rem-7apg3OU",
        "rem-WZ4Q5Ns",
        "rem-VKZWuLQ",
        "rem-xj2QHRw",
        "times",
        "times-7apg3OU",
        "times-WZ4Q5Ns",
        "times-VKZWuLQ",
        "times-xj2QHRw",
        "toByte",
        "toByte-impl",
        "toDouble",
        "",
        "toDouble-impl",
        "(B)D",
        "toFloat",
        "",
        "toFloat-impl",
        "(B)F",
        "toInt",
        "toInt-impl",
        "toLong",
        "",
        "toLong-impl",
        "(B)J",
        "toShort",
        "",
        "toShort-impl",
        "(B)S",
        "toString",
        "",
        "toString-impl",
        "(B)Ljava/lang/String;",
        "toUByte",
        "toUByte-w2LRezQ",
        "toUInt",
        "toUInt-pVg5ArA",
        "toULong",
        "toULong-s-VKNKU",
        "toUShort",
        "toUShort-Mh2AYeg",
        "xor",
        "xor-7apg3OU",
        "Companion",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation

.annotation runtime Lkotlin/jvm/JvmInline;
.end annotation


# static fields
.field public static final Companion:Lkotlin/UByte$Companion;

.field public static final MAX_VALUE:B = -0x1t

.field public static final MIN_VALUE:B = 0x0t

.field public static final SIZE_BITS:I = 0x8

.field public static final SIZE_BYTES:I = 0x1


# instance fields
.field private final data:B


# direct methods
.method static constructor <clinit>()V
    .registers 2

    new-instance v0, Lkotlin/UByte$Companion;

    const/4 v1, 0x0

    invoke-direct {v0, v1}, Lkotlin/UByte$Companion;-><init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V

    sput-object v0, Lkotlin/UByte;->Companion:Lkotlin/UByte$Companion;

    return-void
.end method

.method private synthetic constructor <init>(B)V
    .registers 2
    .param p1, "data"    # B

    .line 16
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-byte p1, p0, Lkotlin/UByte;->data:B

    return-void
.end method

.method private static final and-7apg3OU(BB)B
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 252
    and-int v0, p0, p1

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method public static final synthetic box-impl(B)Lkotlin/UByte;
    .registers 2

    new-instance v0, Lkotlin/UByte;

    invoke-direct {v0, p0}, Lkotlin/UByte;-><init>(B)V

    return-object v0
.end method

.method private compareTo-7apg3OU(B)I
    .registers 4
    .param p1, "other"    # B

    invoke-virtual {p0}, Lkotlin/UByte;->unbox-impl()B

    move-result v0

    .line 47
    and-int/lit16 v0, v0, 0xff

    and-int/lit16 v1, p1, 0xff

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method private static compareTo-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 47
    and-int/lit16 v0, p0, 0xff

    and-int/lit16 v1, p1, 0xff

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method private static final compareTo-VKZWuLQ(BJ)I
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 71
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UByte$$ExternalSyntheticBackport4;->m(JJ)I

    move-result v0

    return v0
.end method

.method private static final compareTo-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 63
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport5;->m(II)I

    move-result v0

    return v0
.end method

.method private static final compareTo-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 55
    and-int/lit16 v0, p0, 0xff

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v0, v1}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method public static constructor-impl(B)B
    .registers 1

    return p0
.end method

.method private static final dec-w2LRezQ(B)B
    .registers 2
    .param p0, "arg0"    # B

    .line 234
    add-int/lit8 v0, p0, -0x1

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final div-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 114
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method private static final div-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 123
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UByte$$ExternalSyntheticBackport3;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final div-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 120
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method private static final div-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 117
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method public static equals-impl(BLjava/lang/Object;)Z
    .registers 4

    instance-of v0, p1, Lkotlin/UByte;

    const/4 v1, 0x0

    if-nez v0, :cond_6

    return v1

    :cond_6
    move-object v0, p1

    check-cast v0, Lkotlin/UByte;

    invoke-virtual {v0}, Lkotlin/UByte;->unbox-impl()B

    move-result v0

    if-eq p0, v0, :cond_10

    return v1

    :cond_10
    const/4 v0, 0x1

    return v0
.end method

.method public static final equals-impl0(BB)Z
    .registers 3

    if-ne p0, p1, :cond_4

    const/4 v0, 0x1

    goto :goto_5

    :cond_4
    const/4 v0, 0x0

    :goto_5
    return v0
.end method

.method private static final floorDiv-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 160
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 181
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UByte$$ExternalSyntheticBackport3;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final floorDiv-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 174
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method private static final floorDiv-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 167
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport0;->m(II)I

    move-result v0

    return v0
.end method

.method public static synthetic getData$annotations()V
    .registers 0

    return-void
.end method

.method public static hashCode-impl(B)I
    .registers 2

    invoke-static {p0}, Ljava/lang/Byte;->hashCode(B)I

    move-result v0

    return v0
.end method

.method private static final inc-w2LRezQ(B)B
    .registers 2
    .param p0, "arg0"    # B

    .line 226
    add-int/lit8 v0, p0, 0x1

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final inv-w2LRezQ(B)B
    .registers 2
    .param p0, "arg0"    # B

    .line 261
    not-int v0, p0

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final minus-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 88
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 97
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    sub-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final minus-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 94
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    sub-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final minus-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 91
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    sub-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final mod-7apg3OU(BB)B
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 191
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final mod-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 218
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final mod-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 209
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    return v0
.end method

.method private static final mod-xj2QHRw(BS)S
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 200
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final or-7apg3OU(BB)B
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 255
    or-int v0, p0, p1

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method

.method private static final plus-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 75
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 84
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    add-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final plus-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 81
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    add-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final plus-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 78
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    add-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final rangeTo-7apg3OU(BB)Lkotlin/ranges/UIntRange;
    .registers 6
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 238
    new-instance v0, Lkotlin/ranges/UIntRange;

    and-int/lit16 v1, p0, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    and-int/lit16 v2, p1, 0xff

    invoke-static {v2}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v2

    const/4 v3, 0x0

    invoke-direct {v0, v1, v2, v3}, Lkotlin/ranges/UIntRange;-><init>(IILkotlin/jvm/internal/DefaultConstructorMarker;)V

    return-object v0
.end method

.method private static final rangeUntil-7apg3OU(BB)Lkotlin/ranges/UIntRange;
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 248
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/ranges/URangesKt;->until-J1ME1BU(II)Lkotlin/ranges/UIntRange;

    move-result-object v0

    return-object v0
.end method

.method private static final rem-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 131
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    return v0
.end method

.method private static final rem-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 152
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    invoke-static {v0, v1, p1, p2}, Lkotlin/UByte$$ExternalSyntheticBackport2;->m(JJ)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final rem-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 145
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    invoke-static {v0, p1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    return v0
.end method

.method private static final rem-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 138
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    invoke-static {v0, v1}, Lkotlin/UByte$$ExternalSyntheticBackport1;->m(II)I

    move-result v0

    return v0
.end method

.method private static final times-7apg3OU(BB)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 101
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    and-int/lit16 v1, p1, 0xff

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-VKZWuLQ(BJ)J
    .registers 7
    .param p0, "arg0"    # B
    .param p1, "other"    # J

    .line 110
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    mul-long/2addr v0, p1

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final times-WZ4Q5Ns(BI)I
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # I

    .line 107
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    mul-int/2addr v0, p1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final times-xj2QHRw(BS)I
    .registers 4
    .param p0, "arg0"    # B
    .param p1, "other"    # S

    .line 104
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    const v1, 0xffff

    and-int/2addr v1, p1

    invoke-static {v1}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v1

    mul-int/2addr v0, v1

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toByte-impl(B)B
    .registers 1
    .param p0, "arg0"    # B

    .line 272
    return p0
.end method

.method private static final toDouble-impl(B)D
    .registers 3
    .param p0, "arg0"    # B

    .line 351
    and-int/lit16 v0, p0, 0xff

    int-to-double v0, v0

    return-wide v0
.end method

.method private static final toFloat-impl(B)F
    .registers 2
    .param p0, "arg0"    # B

    .line 344
    and-int/lit16 v0, p0, 0xff

    int-to-float v0, v0

    return v0
.end method

.method private static final toInt-impl(B)I
    .registers 2
    .param p0, "arg0"    # B

    .line 292
    and-int/lit16 v0, p0, 0xff

    return v0
.end method

.method private static final toLong-impl(B)J
    .registers 5
    .param p0, "arg0"    # B

    .line 302
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    return-wide v0
.end method

.method private static final toShort-impl(B)S
    .registers 2
    .param p0, "arg0"    # B

    .line 282
    int-to-short v0, p0

    and-int/lit16 v0, v0, 0xff

    int-to-short v0, v0

    return v0
.end method

.method public static toString-impl(B)Ljava/lang/String;
    .registers 2
    .param p0, "arg0"    # B

    .line 353
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method private static final toUByte-w2LRezQ(B)B
    .registers 1
    .param p0, "arg0"    # B

    .line 306
    return p0
.end method

.method private static final toUInt-pVg5ArA(B)I
    .registers 2
    .param p0, "arg0"    # B

    .line 326
    and-int/lit16 v0, p0, 0xff

    invoke-static {v0}, Lkotlin/UInt;->constructor-impl(I)I

    move-result v0

    return v0
.end method

.method private static final toULong-s-VKNKU(B)J
    .registers 5
    .param p0, "arg0"    # B

    .line 336
    int-to-long v0, p0

    const-wide/16 v2, 0xff

    and-long/2addr v0, v2

    invoke-static {v0, v1}, Lkotlin/ULong;->constructor-impl(J)J

    move-result-wide v0

    return-wide v0
.end method

.method private static final toUShort-Mh2AYeg(B)S
    .registers 2
    .param p0, "arg0"    # B

    .line 316
    int-to-short v0, p0

    and-int/lit16 v0, v0, 0xff

    int-to-short v0, v0

    invoke-static {v0}, Lkotlin/UShort;->constructor-impl(S)S

    move-result v0

    return v0
.end method

.method private static final xor-7apg3OU(BB)B
    .registers 3
    .param p0, "arg0"    # B
    .param p1, "other"    # B

    .line 258
    xor-int v0, p0, p1

    int-to-byte v0, v0

    invoke-static {v0}, Lkotlin/UByte;->constructor-impl(B)B

    move-result v0

    return v0
.end method


# virtual methods
.method public bridge synthetic compareTo(Ljava/lang/Object;)I
    .registers 4
    .param p1, "other"    # Ljava/lang/Object;

    .line 13
    move-object v0, p1

    check-cast v0, Lkotlin/UByte;

    invoke-virtual {v0}, Lkotlin/UByte;->unbox-impl()B

    move-result v0

    invoke-virtual {p0}, Lkotlin/UByte;->unbox-impl()B

    move-result v1

    and-int/lit16 v1, v1, 0xff

    and-int/lit16 v0, v0, 0xff

    invoke-static {v1, v0}, Lkotlin/jvm/internal/Intrinsics;->compare(II)I

    move-result v0

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .registers 3

    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0, p1}, Lkotlin/UByte;->equals-impl(BLjava/lang/Object;)Z

    move-result v0

    return v0
.end method

.method public hashCode()I
    .registers 2

    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0}, Lkotlin/UByte;->hashCode-impl(B)I

    move-result v0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .registers 2

    .line 353
    iget-byte v0, p0, Lkotlin/UByte;->data:B

    invoke-static {v0}, Lkotlin/UByte;->toString-impl(B)Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final synthetic unbox-impl()B
    .registers 2

    iget-byte v0, p0, Lkotlin/UByte;->data:B

    return v0
.end method

###### Class kotlin.UByte.Companion (kotlin.UByte$Companion)
.class public final Lkotlin/UByte$Companion;
.super Ljava/lang/Object;
.source "UByte.kt"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lkotlin/UByte;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "Companion"
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u001c\n\u0002\u0018\u0002\n\u0002\u0010\u0000\n\u0002\u0008\u0002\n\u0002\u0018\u0002\n\u0002\u0008\u0003\n\u0002\u0010\u0008\n\u0002\u0008\u0002\u0008\u0086\u0003\u0018\u00002\u00020\u0001B\u0007\u0008\u0002\u00a2\u0006\u0002\u0010\u0002R\u0016\u0010\u0003\u001a\u00020\u0004X\u0086T\u00f8\u0001\u0000\u00f8\u0001\u0001\u00a2\u0006\u0004\n\u0002\u0010\u0005R\u0016\u0010\u0006\u001a\u00020\u0004X\u0086T\u00f8\u0001\u0000\u00f8\u0001\u0001\u00a2\u0006\u0004\n\u0002\u0010\u0005R\u000e\u0010\u0007\u001a\u00020\u0008X\u0086T\u00a2\u0006\u0002\n\u0000R\u000e\u0010\t\u001a\u00020\u0008X\u0086T\u00a2\u0006\u0002\n\u0000\u0082\u0002\u0008\n\u0002\u0008\u0019\n\u0002\u0008!\u00a8\u0006\n"
    }
    d2 = {
        "Lkotlin/UByte$Companion;",
        "",
        "()V",
        "MAX_VALUE",
        "Lkotlin/UByte;",
        "B",
        "MIN_VALUE",
        "SIZE_BITS",
        "",
        "SIZE_BYTES",
        "kotlin-stdlib"
    }
    k = 0x1
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x30
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 18
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public synthetic constructor <init>(Lkotlin/jvm/internal/DefaultConstructorMarker;)V
    .registers 2

    invoke-direct {p0}, Lkotlin/UByte$Companion;-><init>()V

    return-void
.end method

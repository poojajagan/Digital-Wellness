###### Class kotlin.jvm.internal.DefaultConstructorMarker (kotlin.jvm.internal.DefaultConstructorMarker)
.class public final Lkotlin/jvm/internal/DefaultConstructorMarker;
.super Ljava/lang/Object;
.source "DefaultConstructorMarker.java"


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 9
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

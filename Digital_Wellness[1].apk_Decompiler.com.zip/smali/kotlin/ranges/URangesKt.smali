###### Class kotlin.ranges.URangesKt (kotlin.ranges.URangesKt)
.class public final Lkotlin/ranges/URangesKt;
.super Lkotlin/ranges/URangesKt___URangesKt;
.source "_URanges.kt"


# annotations
.annotation runtime Lkotlin/Metadata;
    d1 = {
        "kotlin/ranges/URangesKt___URangesKt"
    }
    k = 0x4
    mv = {
        0x1,
        0x8,
        0x0
    }
    xi = 0x31
.end annotation


# direct methods
.method private constructor <init>()V
    .registers 1

    .line 1
    invoke-direct {p0}, Lkotlin/ranges/URangesKt___URangesKt;-><init>()V

    return-void
.end method
